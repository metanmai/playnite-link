using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using PlayniteAchievements.Providers.Settings;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace PlayniteAchievements.Providers.Steam
{
    /// <summary>
    /// Steam-specific provider settings.
    /// </summary>
    public class SteamSettings : ProviderSettingsBase
    {
        private string _steamUserId;
        private string _steamInstallPathOverride;
        private SteamHuntersCategoryMode _steamHuntersCategoryMode = SteamHuntersCategoryMode.Merge;
        private ObservableCollection<SteamIgnoredFriend> _ignoredFriends =
            new ObservableCollection<SteamIgnoredFriend>();

        /// <inheritdoc />
        public override string ProviderKey => "Steam";

        /// <summary>
        /// Gets or sets the last successfully probed Steam user ID.
        /// This is derived auth state, not user-editable configuration.
        /// </summary>
        public string SteamUserId
        {
            get => _steamUserId;
            set => SetValue(ref _steamUserId, value);
        }

        /// <summary>
        /// Optional Steam installation directory. Empty uses the current-user registry value.
        /// </summary>
        public string SteamInstallPathOverride
        {
            get => _steamInstallPathOverride;
            set => SetValue(ref _steamInstallPathOverride, value);
        }

        /// <summary>
        /// Whether and how SteamHunters categories combine with Steam's own achievement sets.
        /// </summary>
        [JsonConverter(typeof(StringEnumConverter))]
        public SteamHuntersCategoryMode SteamHuntersCategoryMode
        {
            get => _steamHuntersCategoryMode;
            set
            {
                SetValue(ref _steamHuntersCategoryMode, value);
                OnPropertyChanged(nameof(UseSteamHuntersForCategories));
            }
        }

        [JsonIgnore]
        public bool UseSteamHuntersForCategories => SteamHuntersCategoryMode != SteamHuntersCategoryMode.Off;

        /// <inheritdoc />
        public override void DeserializeFromJson(string json)
        {
            base.DeserializeFromJson(json);
            ApplyLegacySteamHuntersSetting(json);
        }

        // Settings saved before the mode existed carry the checkbox UseSteamHuntersForCategories
        // (default off). Unchecked maps to Off and checked to Merge; JSON that already has a mode
        // keeps it.
        private void ApplyLegacySteamHuntersSetting(string json)
        {
            if (string.IsNullOrWhiteSpace(json))
            {
                return;
            }

            JObject obj;
            try
            {
                obj = JObject.Parse(json);
            }
            catch (JsonException)
            {
                return;
            }

            if (obj[nameof(SteamHuntersCategoryMode)] != null ||
                obj[nameof(UseSteamHuntersForCategories)]?.Type != JTokenType.Boolean)
            {
                return;
            }

            SteamHuntersCategoryMode = obj.Value<bool>(nameof(UseSteamHuntersForCategories))
                ? SteamHuntersCategoryMode.Merge
                : SteamHuntersCategoryMode.Off;
        }

        public ObservableCollection<SteamIgnoredFriend> IgnoredFriends
        {
            get => _ignoredFriends;
            set => SetValue(
                ref _ignoredFriends,
                new ObservableCollection<SteamIgnoredFriend>(
                    (value ?? new ObservableCollection<SteamIgnoredFriend>())
                    .Where(friend => !string.IsNullOrWhiteSpace(friend?.SteamId))
                    .GroupBy(friend => friend.SteamId.Trim(), StringComparer.OrdinalIgnoreCase)
                    .Select(group => group.First().Normalize())));
        }

        public bool IsFriendIgnored(string steamId)
        {
            return !string.IsNullOrWhiteSpace(steamId) &&
                   IgnoredFriends.Any(friend =>
                       string.Equals(friend?.SteamId, steamId.Trim(), StringComparison.OrdinalIgnoreCase));
        }

        public HashSet<string> GetIgnoredSteamIds()
        {
            return new HashSet<string>(
                IgnoredFriends
                    .Where(friend => !string.IsNullOrWhiteSpace(friend?.SteamId))
                    .Select(friend => friend.SteamId.Trim()),
                StringComparer.OrdinalIgnoreCase);
        }

        public void AddIgnoredFriend(string steamId, string displayName, string avatarUrl)
        {
            if (string.IsNullOrWhiteSpace(steamId))
            {
                return;
            }

            var normalizedId = steamId.Trim();
            var existing = IgnoredFriends.FirstOrDefault(friend =>
                string.Equals(friend?.SteamId, normalizedId, StringComparison.OrdinalIgnoreCase));
            if (existing != null)
            {
                existing.DisplayName = string.IsNullOrWhiteSpace(displayName) ? existing.DisplayName : displayName.Trim();
                existing.AvatarUrl = string.IsNullOrWhiteSpace(avatarUrl) ? existing.AvatarUrl : avatarUrl.Trim();
                return;
            }

            IgnoredFriends.Add(new SteamIgnoredFriend
            {
                SteamId = normalizedId,
                DisplayName = string.IsNullOrWhiteSpace(displayName) ? normalizedId : displayName.Trim(),
                AvatarUrl = string.IsNullOrWhiteSpace(avatarUrl) ? null : avatarUrl.Trim(),
                IgnoredUtc = DateTime.UtcNow
            });
            OnPropertyChanged(nameof(IgnoredFriends));
        }

        public bool RemoveIgnoredFriend(string steamId)
        {
            if (string.IsNullOrWhiteSpace(steamId))
            {
                return false;
            }

            var normalizedId = steamId.Trim();
            var removed = false;
            for (var i = IgnoredFriends.Count - 1; i >= 0; i--)
            {
                if (!string.Equals(IgnoredFriends[i]?.SteamId, normalizedId, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                IgnoredFriends.RemoveAt(i);
                removed = true;
            }

            if (removed)
            {
                OnPropertyChanged(nameof(IgnoredFriends));
            }

            return removed;
        }
    }

    public enum SteamHuntersCategoryMode
    {
        /// <summary>SteamHunters is not used; categories come from Steam's achievement sets only.</summary>
        Off = 0,

        /// <summary>
        /// Steam's named achievement sets keep their category; SteamHunters categorizes the
        /// rest and adds obtainability.
        /// </summary>
        Merge = 1,

        /// <summary>SteamHunters categories replace Steam's achievement sets.</summary>
        Override = 2
    }

    public sealed class SteamIgnoredFriend
    {
        public string SteamId { get; set; }
        public string DisplayName { get; set; }
        public string AvatarUrl { get; set; }
        public DateTime IgnoredUtc { get; set; }

        public DateTime IgnoredLocal => IgnoredUtc.Kind == DateTimeKind.Unspecified
            ? DateTime.SpecifyKind(IgnoredUtc, DateTimeKind.Utc).ToLocalTime()
            : IgnoredUtc.ToUniversalTime().ToLocalTime();

        public SteamIgnoredFriend Normalize()
        {
            SteamId = SteamId?.Trim();
            DisplayName = string.IsNullOrWhiteSpace(DisplayName) ? SteamId : DisplayName.Trim();
            AvatarUrl = string.IsNullOrWhiteSpace(AvatarUrl) ? null : AvatarUrl.Trim();
            if (IgnoredUtc == default)
            {
                IgnoredUtc = DateTime.UtcNow;
            }

            if (IgnoredUtc.Kind == DateTimeKind.Local)
            {
                IgnoredUtc = IgnoredUtc.ToUniversalTime();
            }

            return this;
        }
    }

}
