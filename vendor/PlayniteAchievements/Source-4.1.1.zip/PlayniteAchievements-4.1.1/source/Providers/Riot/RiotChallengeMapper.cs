using Newtonsoft.Json;
using PlayniteAchievements.Models.Achievements;
using PlayniteAchievements.Services.Achievements;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace PlayniteAchievements.Providers.Riot
{
    /// <summary>
    /// Pure mapping from CommunityDragon challenge metadata plus a player's challenge state to
    /// <see cref="AchievementDetail"/>. Free of HTTP, WPF and Playnite dependencies so it can be
    /// unit tested against captured payloads.
    /// </summary>
    internal static class RiotChallengeMapper
    {
        /// <summary>
        /// CommunityDragon serves game assets from the default locale regardless of the locale the
        /// metadata itself was fetched in; art is not localized.
        /// </summary>
        private const string AssetRoot = "https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/";

        private const string AssetPathPrefix = "/lol-game-data/assets/";

        /// <summary>Category type applied to challenges whose end date is still ahead.</summary>
        private const string MissableCategoryType = "Missable";

        /// <summary>Category type applied to challenges that can no longer be progressed.</summary>
        private const string UnobtainableCategoryType = "Unobtainable";

        private const string IsCategoryTag = "isCategory";
        private const string ParentTag = "parent";
        private const string SeasonTag = "season";
        private const string ArchivedState = "ARCHIVED";

        public static CDragonChallengeFile ParseMetadata(string json)
        {
            if (string.IsNullOrWhiteSpace(json))
            {
                return null;
            }

            return JsonConvert.DeserializeObject<CDragonChallengeFile>(json);
        }

        public static RiotPlayerInfoDto ParsePlayerData(string json)
        {
            if (string.IsNullOrWhiteSpace(json))
            {
                return null;
            }

            return JsonConvert.DeserializeObject<RiotPlayerInfoDto>(json);
        }

        /// <summary>
        /// Parses the <c>challenges/percentiles</c> payload: challenge id to level name to percentile.
        /// </summary>
        /// <summary>Ids of the challenges the <c>challenges/config</c> list reports as ARCHIVED.</summary>
        public static IReadOnlyCollection<long> ParseArchivedChallengeIds(string json)
        {
            var result = new HashSet<long>();
            if (string.IsNullOrWhiteSpace(json))
            {
                return result;
            }

            var configs = JsonConvert.DeserializeObject<List<RiotChallengeConfigDto>>(json);
            foreach (var config in configs ?? new List<RiotChallengeConfigDto>())
            {
                if (config != null && string.Equals(config.State, ArchivedState, StringComparison.OrdinalIgnoreCase))
                {
                    result.Add(config.Id);
                }
            }

            return result;
        }

        public static IReadOnlyDictionary<long, IReadOnlyDictionary<string, double>> ParsePercentiles(string json)
        {
            var empty = new Dictionary<long, IReadOnlyDictionary<string, double>>();
            if (string.IsNullOrWhiteSpace(json))
            {
                return empty;
            }

            var raw = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, double>>>(json);
            if (raw == null)
            {
                return empty;
            }

            var result = new Dictionary<long, IReadOnlyDictionary<string, double>>();
            foreach (var pair in raw)
            {
                if (!TryParseChallengeId(pair.Key, out var id) || pair.Value == null)
                {
                    continue;
                }

                result[id] = new Dictionary<string, double>(pair.Value, StringComparer.OrdinalIgnoreCase);
            }

            return result;
        }

        /// <summary>
        /// Builds the achievement list. <paramref name="categoryDisplayNames"/> maps the five
        /// top-level category ids to localized labels, since CommunityDragon exposes them only as
        /// raw codes (IMAGINATION, EXPERTISE, ...).
        /// </summary>
        /// <param name="nowUtc">Reference time for deciding whether a timed challenge is still open.</param>
        public static List<AchievementDetail> BuildAchievements(
            CDragonChallengeFile metadata,
            RiotPlayerChallengeState playerState,
            IReadOnlyDictionary<string, string> categoryDisplayNames,
            DateTime nowUtc)
        {
            var results = new List<TierEntry>();
            if (metadata?.Challenges == null || metadata.Challenges.Count == 0)
            {
                return new List<AchievementDetail>();
            }

            var playerByChallenge = BuildPlayerIndex(playerState);
            var percentiles = playerState?.LevelPercentiles
                ?? new Dictionary<long, IReadOnlyDictionary<string, double>>();
            var archivedIds = new HashSet<long>(playerState?.ArchivedChallengeIds ?? Array.Empty<long>());

            foreach (var entry in metadata.Challenges)
            {
                if (!TryParseChallengeId(entry.Key, out var challengeId) || entry.Value == null)
                {
                    continue;
                }

                var challenge = entry.Value;

                // Ids 0-5 are the crystal root and the five category point meters. They carry no
                // token art and are progress totals rather than objectives, so they are not
                // achievements.
                if (IsCategoryNode(challenge))
                {
                    continue;
                }

                playerByChallenge.TryGetValue(challengeId, out var playerInfo);
                percentiles.TryGetValue(challengeId, out var challengePercentiles);

                results.AddRange(BuildTierAchievements(
                    challengeId,
                    challenge,
                    playerInfo,
                    challengePercentiles,
                    metadata.Challenges,
                    categoryDisplayNames,
                    archivedIds,
                    nowUtc));
            }

            // Group by category so the default (provider) order reads the way the League client
            // presents challenges, then keep a challenge's tiers together and in ladder order.
            return results
                .OrderBy(entry => entry.Achievement.Category ?? string.Empty, StringComparer.CurrentCultureIgnoreCase)
                .ThenBy(entry => entry.ChallengeSortName, StringComparer.CurrentCultureIgnoreCase)
                .ThenBy(entry => entry.TierRank)
                .Select(entry => entry.Achievement)
                .ToList();
        }

        /// <summary>
        /// Carries the sort keys alongside the achievement so ordering does not have to re-parse
        /// the composed display name.
        /// </summary>
        private sealed class TierEntry
        {
            public AchievementDetail Achievement { get; set; }

            public string ChallengeSortName { get; set; }

            public int TierRank { get; set; }
        }

        /// <summary>
        /// One achievement per tier of a challenge. A challenge is earned again at each successive
        /// tier, so a tier is the only thing here that is actually all-or-nothing, and modelling it
        /// that way lets a tier climb be an ordinary locked-to-unlocked transition.
        /// </summary>
        private static IEnumerable<TierEntry> BuildTierAchievements(
            long challengeId,
            CDragonChallenge challenge,
            RiotChallengeInfoDto playerInfo,
            IReadOnlyDictionary<string, double> challengePercentiles,
            IReadOnlyDictionary<string, CDragonChallenge> allChallenges,
            IReadOnlyDictionary<string, string> categoryDisplayNames,
            ISet<long> archivedIds,
            DateTime nowUtc)
        {
            var ladder = BuildThresholdLadder(challenge);
            if (ladder.Count == 0)
            {
                yield break;
            }

            var playerRank = RiotChallengeLevels.GetRank(playerInfo?.Level);
            var value = playerInfo?.Value ?? 0d;
            var category = ResolveCategory(challenge, allChallenges, categoryDisplayNames);
            var categoryType = ResolveTimedCategoryType(challengeId, challenge, allChallenges, archivedIds, nowUtc);
            var description = FirstNonBlank(challenge.Description, challenge.DescriptionShort);

            foreach (var tier in ladder)
            {
                var tierName = RiotChallengeLevels.Ascending[tier.Rank];
                var unlocked = playerRank >= tier.Rank;
                var iconUrl = ResolveIconUrl(challenge, tierName);
                var percent = ResolveTierPercent(challengePercentiles, tier.Rank);

                var achievement = new AchievementDetail
                {
                    ApiName = BuildTierApiName(challengeId, tierName),

                    // Every tier of a challenge shares its name, so the tier is composed into the
                    // display name to tell the rows apart without relying on the token art alone.
                    DisplayName = ComposeTierDisplayName(challenge.Name, tierName),
                    Description = description,
                    UnlockedIconPath = iconUrl,

                    // Challenge token art has no separate locked variant; the display layer derives
                    // the greyscale locked rendering from the same source.
                    LockedIconPath = iconUrl,

                    Unlocked = unlocked,

                    // Riot timestamps only the tier the player currently holds. Lower tiers are
                    // known to be earned but not when, and an invented timestamp would be a lie the
                    // unlock feed would then order by.
                    UnlockTimeUtc = tier.Rank == playerRank ? ToUtc(playerInfo?.AchievedTime) : null,

                    Category = category,
                    CategoryType = categoryType,
                    GlobalPercentUnlocked = percent
                };

                if (percent.HasValue)
                {
                    achievement.Rarity = PercentRarityHelper.GetRarityTier(percent.Value);
                }

                ApplyTierProgress(achievement, challenge, value, tier.Value);

                yield return new TierEntry
                {
                    Achievement = achievement,
                    ChallengeSortName = challenge.Name ?? string.Empty,
                    TierRank = tier.Rank
                };
            }
        }

        /// <summary>
        /// The challenge name with its tier appended, e.g. "Always On Time (Iron)". The bare name is
        /// kept when either part is missing rather than composing an empty parenthetical. This is
        /// display text only; <see cref="BuildTierApiName"/> remains the row's identity.
        /// </summary>
        internal static string ComposeTierDisplayName(string challengeName, string tierName)
        {
            var name = (challengeName ?? string.Empty).Trim();
            var tierLabel = RiotChallengeLevels.GetDisplayName(tierName);
            if (name.Length == 0 || tierLabel.Length == 0)
            {
                return challengeName;
            }

            return name + " (" + tierLabel + ")";
        }

        /// <summary>
        /// Stable per-tier identity. It keys the icon cache, overrides, goals and notes, so it must
        /// never shift with a rename or a locale change.
        /// </summary>
        internal static string BuildTierApiName(long challengeId, string tierName)
            => challengeId.ToString(CultureInfo.InvariantCulture) + ":" + RiotChallengeLevels.Normalize(tierName);

        /// <summary>
        /// Progress toward this tier's own threshold. An earned tier reads full; the tiers above it
        /// show how far the same running value has come, which is what a locked achievement's
        /// progress bar means everywhere else.
        /// </summary>
        private static void ApplyTierProgress(
            AchievementDetail achievement,
            CDragonChallenge challenge,
            double value,
            double threshold)
        {
            // A reverse-direction challenge counts down, so a rising bar would read backwards.
            if (challenge.ReverseDirection || threshold <= 0)
            {
                return;
            }

            achievement.ProgressNum = ToProgressInt(Math.Min(value, threshold));
            achievement.ProgressDenom = ToProgressInt(threshold);
        }

        private sealed class ThresholdTier
        {
            public int Rank { get; set; }

            public double Value { get; set; }
        }

        private static List<ThresholdTier> BuildThresholdLadder(CDragonChallenge challenge)
        {
            if (challenge.Thresholds == null || challenge.Thresholds.Count == 0)
            {
                return new List<ThresholdTier>();
            }

            return challenge.Thresholds
                .Where(pair => RiotChallengeLevels.GetRank(pair.Key) > 0 && pair.Value != null)
                .Select(pair => new ThresholdTier
                {
                    Rank = RiotChallengeLevels.GetRank(pair.Key),
                    Value = pair.Value.Value
                })
                .OrderBy(tier => tier.Rank)
                .ToList();
        }

        /// <summary>
        /// Riot reports percentiles as a 0..1 fraction of the player base at or above a tier, which
        /// is the same "share of players who have it" the rarity model expects once scaled to 0-100.
        ///
        /// Riot writes a literal 0.0 where it has no figure, which is not the same as "no players":
        /// live data shows tables such as IRON=0 with MASTER=0.029, and nobody can hold Master
        /// without holding Iron. Zeroes are therefore treated as absent, not as ultra-rare.
        /// </summary>
        private static double? ResolveTierPercent(
            IReadOnlyDictionary<string, double> challengePercentiles,
            int tierRank)
        {
            // Per-tier achievements read the table at their own tier, which is exactly the share of
            // players holding that tier - no estimating from the player's own figure needed.
            var nearest = FindNearestPercentile(challengePercentiles, Math.Max(tierRank, 1));

            // Nothing usable in the table leaves rarity unset rather than guessed; the display layer
            // treats an absent percentage as the common default.
            return nearest.HasValue ? ScalePercentile(nearest.Value) : (double?)null;
        }

        /// <summary>
        /// Finds the closest populated tier to <paramref name="targetRank"/>, searching downward
        /// first. Percentiles descend as tiers rise, so a lower tier bounds the target from above —
        /// erring toward "more common" rather than inflating rarity on a gap in Riot's data.
        /// </summary>
        private static double? FindNearestPercentile(
            IReadOnlyDictionary<string, double> challengePercentiles,
            int targetRank)
        {
            if (challengePercentiles == null || challengePercentiles.Count == 0)
            {
                return null;
            }

            for (var rank = targetRank; rank >= 1; rank--)
            {
                if (TryGetRealPercentile(challengePercentiles, rank, out var below))
                {
                    return below;
                }
            }

            for (var rank = targetRank + 1; rank < RiotChallengeLevels.Ascending.Length; rank++)
            {
                if (TryGetRealPercentile(challengePercentiles, rank, out var above))
                {
                    return above;
                }
            }

            return null;
        }

        private static bool TryGetRealPercentile(
            IReadOnlyDictionary<string, double> challengePercentiles,
            int rank,
            out double percentile)
        {
            percentile = 0d;

            if (!challengePercentiles.TryGetValue(RiotChallengeLevels.Ascending[rank], out var value) ||
                !IsRealPercentile(value))
            {
                return false;
            }

            percentile = value;
            return true;
        }

        private static bool IsRealPercentile(double? percentile)
            => percentile.HasValue && percentile.Value > 0d && !double.IsNaN(percentile.Value);

        private static double ScalePercentile(double percentile)
        {
            var scaled = percentile * 100d;
            if (scaled < 0d) return 0d;
            if (scaled > 100d) return 100d;
            return scaled;
        }

        /// <summary>
        /// Resolves the token art for the player's current tier, falling back to the lowest tier art
        /// available so locked challenges still render their own icon rather than a generic one.
        /// </summary>
        private static string ResolveIconUrl(CDragonChallenge challenge, string level)
        {
            if (challenge.LevelToIconPath == null || challenge.LevelToIconPath.Count == 0)
            {
                return null;
            }

            var byLevel = new Dictionary<string, string>(challenge.LevelToIconPath, StringComparer.OrdinalIgnoreCase);

            if (RiotChallengeLevels.IsUnlocked(level) &&
                byLevel.TryGetValue(level, out var exact) &&
                !string.IsNullOrWhiteSpace(exact))
            {
                return BuildAssetUrl(exact);
            }

            for (var rank = 1; rank < RiotChallengeLevels.Ascending.Length; rank++)
            {
                if (byLevel.TryGetValue(RiotChallengeLevels.Ascending[rank], out var path) &&
                    !string.IsNullOrWhiteSpace(path))
                {
                    return BuildAssetUrl(path);
                }
            }

            return null;
        }

        /// <summary>
        /// The token art of the highest tier the challenge publishes art for.
        /// </summary>
        private static string ResolveTopTierIconUrl(CDragonChallenge challenge)
        {
            if (challenge?.LevelToIconPath == null || challenge.LevelToIconPath.Count == 0)
            {
                return null;
            }

            var byLevel = new Dictionary<string, string>(challenge.LevelToIconPath, StringComparer.OrdinalIgnoreCase);
            for (var rank = RiotChallengeLevels.Ascending.Length - 1; rank >= 1; rank--)
            {
                if (byLevel.TryGetValue(RiotChallengeLevels.Ascending[rank], out var path) &&
                    !string.IsNullOrWhiteSpace(path))
                {
                    return BuildAssetUrl(path);
                }
            }

            return null;
        }

        /// <summary>
        /// Applies CommunityDragon's documented rule: <c>/lol-game-data/assets/&lt;path&gt;</c> maps to
        /// <c>plugins/rcp-be-lol-game-data/global/default/&lt;lowercased path&gt;</c>.
        /// </summary>
        public static string BuildAssetUrl(string assetPath)
        {
            if (string.IsNullOrWhiteSpace(assetPath))
            {
                return null;
            }

            var trimmed = assetPath.Trim();
            if (trimmed.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
                trimmed.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            {
                return trimmed;
            }

            var relative = trimmed.StartsWith(AssetPathPrefix, StringComparison.OrdinalIgnoreCase)
                ? trimmed.Substring(AssetPathPrefix.Length)
                : trimmed.TrimStart('/');

            return AssetRoot + relative.ToLowerInvariant();
        }

        /// <summary>
        /// Default category art for capstone groups: a challenge's category is named after the
        /// capstone it hangs off, so that capstone's token art belongs to the category. The highest
        /// tier's art is used: it does not depend on the player's rank, and the low tiers' tokens are
        /// grey (Iron is a dark grey medallion). The five top-level categories carry no art and get
        /// no entry.
        /// </summary>
        public static List<(string Label, string IconUrl)> BuildCategoryArtPlan(
            CDragonChallengeFile metadata,
            IReadOnlyDictionary<string, string> categoryDisplayNames)
        {
            var plan = new List<(string Label, string IconUrl)>();
            if (metadata?.Challenges == null || metadata.Challenges.Count == 0)
            {
                return plan;
            }

            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var entry in metadata.Challenges.OrderBy(pair => pair.Key, StringComparer.Ordinal))
            {
                var challenge = entry.Value;
                if (challenge == null || IsCategoryNode(challenge))
                {
                    continue;
                }

                var parentId = GetTag(challenge, ParentTag);
                if (string.IsNullOrWhiteSpace(parentId) ||
                    !metadata.Challenges.TryGetValue(parentId, out var parent) ||
                    parent == null ||
                    IsCategoryNode(parent))
                {
                    continue;
                }

                var label = ResolveCategory(challenge, metadata.Challenges, categoryDisplayNames);
                var iconUrl = ResolveTopTierIconUrl(parent);
                if (!string.IsNullOrWhiteSpace(label) &&
                    !string.IsNullOrWhiteSpace(iconUrl) &&
                    seen.Add(label))
                {
                    plan.Add((label, iconUrl));
                }
            }

            return plan;
        }

        /// <summary>
        /// The owning group's display name: the parent capstone for a leaf challenge, or the
        /// localized top-level category for a capstone. Null when the challenge has no parent —
        /// providers must not invent a sentinel label.
        /// </summary>
        private static string ResolveCategory(
            CDragonChallenge challenge,
            IReadOnlyDictionary<string, CDragonChallenge> allChallenges,
            IReadOnlyDictionary<string, string> categoryDisplayNames)
        {
            // A challenge hangs off a capstone, and the capstone off one of the five top-level
            // categories, so climb until a category resolves rather than stopping at the first
            // hop. A challenge parented straight to a category still yields the single segment
            // this returned before. The visited set guards against a cycle in the parent tags.
            var segments = new List<string>();
            var visited = new HashSet<string>(StringComparer.Ordinal);
            var parentId = GetTag(challenge, ParentTag);

            while (!string.IsNullOrWhiteSpace(parentId) && visited.Add(parentId))
            {
                if (categoryDisplayNames != null &&
                    categoryDisplayNames.TryGetValue(parentId, out var localized) &&
                    !string.IsNullOrWhiteSpace(localized))
                {
                    segments.Insert(0, localized);
                    break;
                }

                if (allChallenges == null ||
                    !allChallenges.TryGetValue(parentId, out var parent) ||
                    parent == null)
                {
                    break;
                }

                // The only category node missing from the display map is the crystal root, which
                // is a progress total rather than a grouping, so it never becomes a segment.
                if (IsCategoryNode(parent))
                {
                    break;
                }

                if (!string.IsNullOrWhiteSpace(parent.Name))
                {
                    segments.Insert(0, parent.Name);
                }

                parentId = GetTag(parent, ParentTag);
            }

            return segments.Count == 0 ? null : CategoryPathHelper.JoinRaw(segments.ToArray());
        }

        // Unobtainable when Riot's config archives the challenge. Otherwise a challenge with an end
        // date is Missable until it passes and Unobtainable afterwards, and a seasonal challenge
        // (one carrying a seasons list or season tag) is Missable in its own year and Unobtainable
        // after it. Neither CommunityDragon nor Riot's config names the current season, and
        // seasonal challenges carry no end date, so the year comes from the seasonal set's id
        // (2022000, 2023009, 2024100, ...). Anything else gets no timed type.
        private static string ResolveTimedCategoryType(
            long challengeId,
            CDragonChallenge challenge,
            IReadOnlyDictionary<string, CDragonChallenge> allChallenges,
            ISet<long> archivedIds,
            DateTime nowUtc)
        {
            if (archivedIds != null && archivedIds.Contains(challengeId))
            {
                return UnobtainableCategoryType;
            }

            if (challenge.EndTimestamp > 0)
            {
                var end = ToUtc(challenge.EndTimestamp);
                if (end.HasValue)
                {
                    return end.Value <= nowUtc ? UnobtainableCategoryType : MissableCategoryType;
                }
            }

            var seasonalYear = ResolveSeasonalYear(challengeId, challenge, allChallenges);
            if (seasonalYear.HasValue)
            {
                return seasonalYear.Value < nowUtc.Year ? UnobtainableCategoryType : MissableCategoryType;
            }

            return null;
        }

        private static bool IsSeasonal(CDragonChallenge challenge)
        {
            return challenge?.Seasons?.Count > 0 ||
                   (challenge?.Tags != null && challenge.Tags.ContainsKey(SeasonTag));
        }

        // The year of the seasonal set a seasonal challenge belongs to, read from the first id in
        // its parent chain (itself first) shaped like a seasonal-set id: seven digits led by the
        // year. Null for non-seasonal challenges and ones no such id reaches.
        private static int? ResolveSeasonalYear(
            long challengeId,
            CDragonChallenge challenge,
            IReadOnlyDictionary<string, CDragonChallenge> allChallenges)
        {
            if (!IsSeasonal(challenge))
            {
                return null;
            }

            var id = challengeId.ToString(CultureInfo.InvariantCulture);
            var current = challenge;
            var visited = new HashSet<string>(StringComparer.Ordinal);
            while (!string.IsNullOrEmpty(id) && visited.Add(id))
            {
                if (TryParseSeasonalSetYear(id, out var year))
                {
                    return year;
                }

                string parentId = null;
                if (current?.Tags == null || !current.Tags.TryGetValue(ParentTag, out parentId))
                {
                    return null;
                }

                id = parentId;
                current = allChallenges != null && parentId != null && allChallenges.TryGetValue(parentId, out var parent)
                    ? parent
                    : null;
            }

            return null;
        }

        private static bool TryParseSeasonalSetYear(string id, out int year)
        {
            year = 0;
            return id != null &&
                   id.Length == 7 &&
                   id.StartsWith("20", StringComparison.Ordinal) &&
                   int.TryParse(id.Substring(0, 4), NumberStyles.None, CultureInfo.InvariantCulture, out year);
        }

        private static bool IsCategoryNode(CDragonChallenge challenge)
        {
            var value = GetTag(challenge, IsCategoryTag);
            return !string.IsNullOrWhiteSpace(value) &&
                   !string.Equals(value, "false", StringComparison.OrdinalIgnoreCase);
        }

        private static string GetTag(CDragonChallenge challenge, string key)
        {
            if (challenge?.Tags == null)
            {
                return null;
            }

            return challenge.Tags.TryGetValue(key, out var value) ? value : null;
        }

        private static Dictionary<long, RiotChallengeInfoDto> BuildPlayerIndex(RiotPlayerChallengeState playerState)
        {
            var index = new Dictionary<long, RiotChallengeInfoDto>();
            if (playerState?.Challenges == null)
            {
                return index;
            }

            foreach (var info in playerState.Challenges)
            {
                if (info == null)
                {
                    continue;
                }

                // Riot has been observed to repeat a challenge id; the higher tier is authoritative.
                if (index.TryGetValue(info.ChallengeId, out var existing) &&
                    RiotChallengeLevels.GetRank(existing.Level) >= RiotChallengeLevels.GetRank(info.Level))
                {
                    continue;
                }

                index[info.ChallengeId] = info;
            }

            return index;
        }

        private static bool TryParseChallengeId(string raw, out long id)
            => long.TryParse((raw ?? string.Empty).Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out id);

        private static DateTime? ToUtc(long? epochMilliseconds)
        {
            if (!epochMilliseconds.HasValue || epochMilliseconds.Value <= 0)
            {
                return null;
            }

            try
            {
                return DateTimeOffset.FromUnixTimeMilliseconds(epochMilliseconds.Value).UtcDateTime;
            }
            catch (ArgumentOutOfRangeException)
            {
                return null;
            }
        }

        private static int ToProgressInt(double value)
        {
            if (double.IsNaN(value) || value <= 0d)
            {
                return 0;
            }

            if (value >= int.MaxValue)
            {
                return int.MaxValue;
            }

            return (int)Math.Round(value, MidpointRounding.AwayFromZero);
        }

        private static string FirstNonBlank(params string[] candidates)
            => candidates?.FirstOrDefault(value => !string.IsNullOrWhiteSpace(value));
    }
}
