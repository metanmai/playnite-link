using PlayniteAchievements.Models;
using PlayniteAchievements.Models.Achievements;
using PlayniteAchievements.Models.Friends;
using PlayniteAchievements.Providers.Settings;
using Playnite.SDK.Models;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace PlayniteAchievements.Providers
{
    public interface IDataProvider
    {
        string ProviderName { get; }
        string ProviderKey { get; }
        string ProviderIconKey { get; }
        string ProviderColorHex { get; }
        bool IsCapable(Game game);

        /// <summary>
        /// Gets whether this provider has valid authentication credentials configured.
        /// This property checks credentials ONLY - it does not consider whether the provider is enabled.
        /// The enabled state is managed separately by ProviderRegistry.
        /// Each provider implements its own validation logic appropriate to its auth requirements.
        /// </summary>
        bool IsAuthenticated { get; }

        /// <summary>
        /// Gets the provider-owned auth session manager when this provider supports live auth probing.
        /// Providers with no external auth return null.
        /// </summary>
        ISessionManager AuthSession { get; }

        /// <summary>
        /// Gets the optional provider-owned friends capability.
        /// Providers that do not support friends return null.
        /// </summary>
        IFriendsProvider Friends { get; }

        Task<RebuildPayload> RefreshAsync(
            IReadOnlyList<Game> gamesToRefresh,
            Action<Game> onGameStarting,
            Func<Game, GameAchievementData, Task> onGameCompleted,
            CancellationToken cancel);

        /// <summary>
        /// Gets the provider-specific settings object.
        /// </summary>
        IProviderSettings GetSettings();

        /// <summary>
        /// Called after settings are loaded to apply them to the provider.
        /// </summary>
        void ApplySettings(IProviderSettings settings);

        /// <summary>
        /// Creates the settings view for this provider.
        /// </summary>
        ProviderSettingsViewBase CreateSettingsView();
    }

    /// <summary>
    /// Optional current-user refresh capability for providers that can produce a safe result
    /// without live web authentication. The provider still owns the final per-game decision.
    /// </summary>
    internal interface IOfflineRefreshFallbackProvider
    {
        bool CanAttemptOfflineRefresh { get; }
    }

    /// <summary>
    /// Optional current-user refresh overload for providers whose definition data comes from a
    /// source worth sparing on frequent programmatic refreshes. With
    /// <c>preferCachedDefinitions</c> set (RefreshOptions.PreferCachedDefinitions, used by the
    /// in-game monitor) the provider reuses its stored definition data instead of re-fetching it.
    /// </summary>
    internal interface IDefinitionCachePreferenceProvider
    {
        Task<RebuildPayload> RefreshAsync(
            IReadOnlyList<Game> gamesToRefresh,
            Action<Game> onGameStarting,
            Func<Game, GameAchievementData, Task> onGameCompleted,
            bool preferCachedDefinitions,
            CancellationToken cancel);
    }
}
